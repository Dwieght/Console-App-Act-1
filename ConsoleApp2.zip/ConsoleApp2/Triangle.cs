﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    public class Triangle : Shape
    {
        public double Length { get; set; }
        public double Height { get; set; }
        public Triangle(double length, double height)
        {
            Length = length; 
            Height = height;
        }

        public override double CalculateArea()
        {
            return (Height * Length) / 2;
        }
    }
}

﻿using ConsoleApp2;
using System;
class Program
{
    public static void Main()
    {
    start:
        Console.BackgroundColor = ConsoleColor.Black;
        Console.ForegroundColor = ConsoleColor.Green;
        Console.Clear();
        Console.WriteLine("WELCOME TO THE CLUB \n 1.) circle \n 2.) rectangle \n 3.) triangle \n 4.) Square \n CHOOSE A SHAPE:");

        string shapeType = Console.ReadLine().ToLower();

        double area = 0.0;
        Shape shape;
        if (shapeType == "circle" || shapeType == "1")
        {
            Again:
            Console.Write("Enter the radius: ");
            bool success = double.TryParse(Console.ReadLine(), out double radius);
            if (success)
            {
                var test = radius;
                shape = new Circle(radius);
            }
            else
            {
                Console.WriteLine("Please Input Number");
                goto Again;
            }
            shape = new Circle(radius);
        }
        else if (shapeType == "rectangle" || shapeType == "2")
        {
            Again:
            Console.Write("Enter the width: ");
            bool success = double.TryParse(Console.ReadLine(), out double width);
            if (success)
            {
                var test = width;
            }
            else
            {
                Console.WriteLine("Please Input Number");
                goto Again;

            }
            rHeight:
            Console.Write("Enter the height: ");
            bool success1 = double.TryParse(Console.ReadLine(),out double height);
            if (success1)
            {
                var test = height;
            }
            else
            {
                Console.WriteLine("Please Input Number");
                goto rHeight;
            }
            shape = new Rectangle(width, height);
        }else if(shapeType == "triangle" || shapeType == "3")
        {
            gLength:
            Console.Write("Enter the length: ");
            bool success = double.TryParse(Console.ReadLine(),out double length);
            if (success)
            {
                var test = length;
            }
            else
            {
                Console.WriteLine("Please Input Number");
                goto gLength;

            }
            gHeight:
            Console.Write("Enter the height: ");
            bool success1 = double.TryParse(Console.ReadLine(), out double height);
            if (success1)
            {
                var test = height;
            }
            else
            {
                Console.WriteLine("Please Input Number");
                goto gHeight;
            }
            shape = new Triangle(length, height);
        }
        else if(shapeType == "square" || shapeType == "4")
        {
            gSide:
            Console.Write("Enter the Side: ");
            bool success = double.TryParse(Console.ReadLine(),out double side);
            if (success) {
                var test = success;
            }
            else
            {
                Console.WriteLine("Please Input Number");
                goto gSide;
            }
            shape = new Square(side);
        }
        else
        {
            
            Console.WriteLine("Invalid shape choice.");
            goto start;
        }
        area = shape.CalculateArea();
        Console.WriteLine($"The area of the {shapeType} is: {area}");
        Console.WriteLine("Press y to Continue..");
        string Continue = Console.ReadLine();
        if(Continue == "y")
        {
            goto start;
        }else
        {
            Environment.Exit(0);
        }

    }
}